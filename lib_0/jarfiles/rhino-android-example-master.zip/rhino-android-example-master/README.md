# rhino-android-example
An example how to use Rhino on android

If you want to try out this app, head over to the release section and install the apk provided there.

If you want to use this code in Android Studio, create a new project and import this as module.
